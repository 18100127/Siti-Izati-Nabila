<!DOCTYPE html>
<html>
<head>
	<title>Korean Culture</title>
</head>
<body>
<h1>All About K-pop Stuff</h1>
	<div class="produk">
					<a href="gambarlima.php">
					<img src="lightstickexo.jpg" alt="">
					<h4>Light Stick Exo</h4>
					<p>Harga : Rp. 500.000,-</p>
				</a>
				</div>
				<div class="produk">
					<a href="gambarenam.php">
					<img src="kaosexo.jpg" alt="">
					<h4>Kaos Exo</h4>
					<p>Harga : Rp. 80.000,-</p>
				</a>
				</div>
				<a href="belajardua.php">kembali ke Halaman Depan </a>
	</div>
</body>
</html>