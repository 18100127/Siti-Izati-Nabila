<!DOCTYPE html>
<html>
<head>
	<title>Case Anime</title>
</head>
<body>
<h3>Case Anime</h3>
<h4>Stock >50</h4>
<h4>Bahan = Silikon</h4>
<h4>Model HP = Vivo, Oppo, Samsung, Iphone, Xiaomi</h4>
<a href="japanculture.php">
<img src="back.png" width="50">
</body>
</html>