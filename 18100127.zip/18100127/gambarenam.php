<!DOCTYPE html>
<html>
<head>
	<title>K-pop Stuff</title>
</head>
<body>
<h3>Kaos EXO</h3>
<h4>Bahan tebal dan nyaman dipakai</h4>
<h4>Size = All size</h4>
<h4>Lingkar dada = 90 cm</h4>
<h4>Panjang = 59 cm</h4>
<h4>Material = soft spandex</h4>
<a href="koreanculture.php">
<img src="back.png" width="50">
</body>
</html>