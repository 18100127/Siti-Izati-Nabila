<!DOCTYPE html>
<html>
<head>
	<title>Dompet Anime</title>
</head>
<body>
<h3>Dompet Death Note</h3>
<h4>Stock = >20</h4>
<h4>Dikirim Dari = Kota Jakarta Pusat</h4>
<h4>Warna sesuai gambar</h4>
<h4>Panjang Barang = 12cm</h4>
<h4>Item Height = 1.5 cm</h4>
<a href="japanculture.php">
<img src="back.png" width="50">
</body>
</html>