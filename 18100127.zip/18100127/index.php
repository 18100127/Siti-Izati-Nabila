 <!DOCTYPE html>
 <html>
 <head>
 	<title>Online Shop</title>
 	<link rel="stylesheet" href="index.css">
 </head>
 <body>
 	<div class="header">
 		<img src="logo.png" width="250">
 	</div>

 	<div class="menu">
 		<ul>
 			<li>Halaman Depan</li>
 			<li>Informasi</li>
 			<li>Kontak</li>
 			<a href="Daftar.php"><li>Daftar</li></a>
 			<a href="Login.php"><li>Login</li></a>
 		</ul>
	</div>

	<div class="content">
		<div class="bagiankiri">
				<div>
					<a href="japanculture.php"> 
					<img src="japan.jpg"> </a>
					<a href="koreanculture.php">
					<img src="koreanculture.png"> </a>
				</div>
		</div>
		<div class="bagiankanan">
			<div class="bagiankanan">
				<p>Menu</p>	
				<h3>Transaksi</h3>
				<h3>Feedback</h3>
				<h3>Pesan</h3>
				<h3>Invite</h3>
				<h3>Pengaturan</h3>
			</div>
		</div>
	</div>
 </body>
 </html>