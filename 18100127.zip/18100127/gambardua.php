<!DOCTYPE html>
<html>
<head>
	<title>Kalung Anime</title>
</head>
<body>
<h3>Kalung Fairy Tail</h3>
<h4>Stock = >100</h4>
<h4>Dikirim Dari = Kota Batam</h4>
<h4>Warna sesuai gambar</h4>
<h4>Bahan besi alloy</h4>
<a href="japanculture.php">
<img src="back.png" width="50">
</body>
</html>