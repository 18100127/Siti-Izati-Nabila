<!DOCTYPE html>
<html>
<head>
	<title>Jaket Anime</title>
</head>
<body>
<h3>Jaket Fairy Tail</h3>
<h4>Stock = >50</h4>
<h4>Dikirim dari = Kota Bandung</h4>
<h4>Jaket ini sangat nyaman dan adem digunakan karena menggunakan bahan Cotton Fleece</h4>
<h4>Didesain casual trendy</h4>
<h4>Ukuran S, M, L, XL</h4>
<a href="japanculture.php">
<img src="back.png" width="50">
</body>
</html>