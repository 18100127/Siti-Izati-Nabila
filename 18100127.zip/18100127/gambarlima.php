<!DOCTYPE html>
<html>
<head>
	<title>K-pop Stuff</title>
</head>
<body>
<h3>Lightstick EXO Ver 3.0</h3>
<h4>Bisa COD</h4>
<h4>Made in China</h4>
<h4>Product Size = 102*38.9*272mm</h4>
<h4>Box Size = 135*50*312mm</h4>
<h4>Power By = 3PCS*AAA Batteries (not includes)</h4>
<a href="koreanculture.php">
<img src="back.png" width="50">
</body>
</html>