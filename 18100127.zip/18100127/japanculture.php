<!DOCTYPE html>
<html>
<head>
	<title>Japan Culture</title>
</head>
<body>
<h1>All About Anime Stuff</h1>
<div class="bagiankiri">
			<h3>Daftar Produk</h3>
			<div class="produk">
					<a href="gambarsatu.php">
					<img src="dompetanime.jpg" alt="">
					<h4>Dompet Death Note</h4>
					<p>Harga : Rp. 210.000,-</p>
				</a>
				</div>
				<div class="produk">
					<a href="gambardua.php">
					<img src="kalungfairytail.jpg" alt="">
					<h4>Kalung Fairy Tail</h4>
					<p>Harga : Rp. 60.000,-</p>
				</a>
				</div>
				<div class="produk">
					<a href="gambartiga.php">
					<img src="jaketfairytail.jpg" alt="">
					<h4>Jaket Fairy Tail</h4>
					<p>Harga : Rp. 180.000,-</p>
				</a>
				</div>
				<div class="produk">
					<a href="gambarempat.php">
					<img src="caseonepiece.jpg" alt="">
					<h4>Case Anime</h4>
					<p>Harga : Rp. 50.000,-</p>
				</a>
				</div>
				<a href="belajardua.php">kembali ke Halaman Depan </a>
</div>
</body>
</html>